package com.example.ui
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.graphicsLayer

import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Schedule
import com.example.ui.theme.*
import com.example.utils.PermissionUtils
import androidx.compose.animation.core.animateFloat
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: XFlowViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onNavigateToTask: (Int) -> Unit,
    onNavigateToProgress: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToStudyPlan: () -> Unit
) {
    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.checkAndRolloverStudyPlans()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val hasActiveSchedules = activeSchedules.isNotEmpty()
    LaunchedEffect(hasActiveSchedules) {
        if (activeSchedules.isNotEmpty()) {
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    var premiumCode by remember { mutableStateOf("") }

    val handleCreateClick = {
        if (PermissionUtils.hasAllPermissions(context)) {
            onNavigateToCreate()
        } else {
            showPermissionDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("XFlow", color = XFlowAccent, fontWeight = FontWeight.Bold) },
                actions = {
                    PremiumStudyPlanButton(isPremium = isPremium) {
                        if (isPremium) {
                            if (PermissionUtils.hasAllPermissions(context)) {
                                onNavigateToStudyPlan()
                            } else {
                                showPermissionDialog = true
                            }
                        } else {
                            showPremiumDialog = true
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = handleCreateClick,
                containerColor = XFlowAccent,
                contentColor = XFlowBackground
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Schedule")
            }
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Active Schedules", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            if (activeSchedules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No active schedules", color = XFlowTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = handleCreateClick,
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                        ) {
                            Text("Create one now")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(activeSchedules) { schedule ->
                        ScheduleCard(schedule, onClick = { onNavigateToTask(schedule.id) })
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Permissions Required") },
            text = { Text("You must grant all required permissions before creating a schedule.") },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionDialog = false
                    onNavigateToPermissions()
                }) {
                    Text("Go to Settings", color = XFlowAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Cancel", color = XFlowTextSecondary)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    isAccent: Boolean = false,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector = androidx.compose.material.icons.Icons.Default.Add
) {
    androidx.compose.material3.Card(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = if (isAccent) com.example.ui.theme.XFlowAccent.copy(alpha = 0.1f) else com.example.ui.theme.XFlowSurface)
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(16.dp)
        ) {
            androidx.compose.material3.Text(
                text = title.ifEmpty { text },
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = com.example.ui.theme.XFlowTextSecondary
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            androidx.compose.material3.Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextPrimary
            )
        }
    }
}

@Composable
fun ScheduleCard(schedule: Schedule, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurface)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Badge(text = if (schedule.isDurationMode) "${schedule.durationMinutes} min" else "${schedule.startTimeStr} - ${schedule.endTimeStr}")
                    Badge(text = if (schedule.isOnlineMode) "Online" else "Offline", isAccent = true)
                    if (schedule.isRunning) {
                        Badge(text = "Running", isAccent = true)
                    }
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            if (schedule.isOnlineMode) {
                OnlineAnimation()
            } else {
                OfflineIllustration()
            }
        }
    }
}

@Composable
fun OnlineAnimation() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        val accent = XFlowAccent
        
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(accent)
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .graphicsLayer { rotationZ = rotation }
            ) {
                val appColors = listOf(
                    androidx.compose.ui.graphics.Color(0xFF4285F4),
                    androidx.compose.ui.graphics.Color(0xFF34A853),
                    androidx.compose.ui.graphics.Color(0xFFFBBC05),
                    androidx.compose.ui.graphics.Color(0xFFEA4335)
                )
                
                Box(modifier = Modifier.size(12.dp).align(Alignment.TopCenter).clip(RoundedCornerShape(3.dp)).background(appColors[0]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterEnd).clip(RoundedCornerShape(3.dp)).background(appColors[1]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.BottomCenter).clip(RoundedCornerShape(3.dp)).background(appColors[2]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterStart).clip(RoundedCornerShape(3.dp)).background(appColors[3]))
            }
        }
    }
}


@Composable
fun OfflineIllustration() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = Icons.Default.Add, // Using placeholder since I don't know what it was
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = XFlowTextSecondary.copy(alpha = 0.5f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Offline Mode",
            color = XFlowTextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500)
        )
    )
    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Study Plan", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(16.dp))
            Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (!isPremium) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("PRO", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}





@Composable
fun Badge(text: String, isAccent: Boolean = false) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
            .background(if (isAccent) com.example.ui.theme.XFlowAccent.copy(alpha = 0.2f) else com.example.ui.theme.XFlowSurfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextSecondary,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )
    }
}
