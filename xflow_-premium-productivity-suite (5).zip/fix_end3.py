import re
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = re.sub(r'PremiumDialog\(showPremiumDialog, \{ showPremiumDialog = false \}, viewModel\)\s*@Composable', 'PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)\n}\n\n@Composable', content)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
