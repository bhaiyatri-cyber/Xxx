#!/bin/bash
sed -i '/const val ABOUT = "about"/a\
    const val THEME_SETTINGS = "theme_settings"' app/src/main/java/com/example/ui/Navigation.kt

sed -i '/composable(Routes.SETTINGS) {/!b;n;n;n;n;n;n;a\
                onNavigateToThemeSettings = { navController.navigate(Routes.THEME_SETTINGS) },' app/src/main/java/com/example/ui/Navigation.kt

sed -i '/composable(Routes.ABOUT) {/i\
        composable(Routes.THEME_SETTINGS) {\
            ThemeSettingsScreen(viewModel = viewModel, onBack = { navController.popBackStack() })\
        }' app/src/main/java/com/example/ui/Navigation.kt
