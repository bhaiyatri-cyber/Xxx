#!/bin/bash
sed -i '/val history by viewModel.history.collectAsStateWithLifecycle()/a\
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()\
    var showPremiumDialog by remember { mutableStateOf(false) }' app/src/main/java/com/example/ui/SettingsScreen.kt

sed -i 's/SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter", onClick = onNavigateToPdf)/SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })/g' app/src/main/java/com/example/ui/SettingsScreen.kt

sed -i '/if (showStatsDialog) {/i\
    if (showPremiumDialog) {\
        AlertDialog(\
            onDismissRequest = { showPremiumDialog = false },\
            title = { Text("Premium Feature", color = XFlowTextPrimary) },\
            text = { Text("This feature is only available for Premium users. Please upgrade from the Home screen.", color = XFlowTextSecondary) },\
            confirmButton = {\
                TextButton(onClick = { showPremiumDialog = false }) {\
                    Text("OK", color = XFlowAccent)\
                }\
            },\
            containerColor = XFlowSurface\
        )\
    }' app/src/main/java/com/example/ui/SettingsScreen.kt
