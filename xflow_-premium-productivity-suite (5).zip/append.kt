@Composable
fun OfflineIllustration() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = Icons.Default.Add, // Using placeholder since I don't know what it was
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = XFlowTextSecondary.copy(alpha = 0.5f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Offline Mode",
            color = XFlowTextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500)
        )
    )
    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Study Plan", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(16.dp))
            Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (!isPremium) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("PRO", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    isAccent: Boolean = false,
    text: String = "",
    icon: ImageVector = Icons.Default.Add
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isAccent) XFlowAccent.copy(alpha = 0.1f) else XFlowSurface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = title.ifEmpty { text },
                style = MaterialTheme.typography.labelMedium,
                color = XFlowTextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = if (isAccent) XFlowAccent else XFlowTextPrimary
            )
        }
    }
}

@Composable
fun ScheduleCard(schedule: Schedule, onClick: () -> Unit = {}) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = XFlowSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = schedule.subject, style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary)
            Spacer(modifier = Modifier.height(4.dp))
            val timeText = if (schedule.isDurationMode) "${schedule.durationMinutes} mins" else "${schedule.startTimeStr} - ${schedule.endTimeStr}"
            Text(text = timeText, style = MaterialTheme.typography.bodySmall, color = XFlowTextSecondary)
            Spacer(modifier = Modifier.height(12.dp))
            val targetSeconds = if (schedule.isDurationMode) schedule.durationMinutes * 60 else 3600
            val progress = if (targetSeconds > 0) (schedule.elapsedSeconds.toFloat() / targetSeconds).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = XFlowAccent,
                trackColor = XFlowSurfaceVariant
            )
        }
    }
}
