package com.example.utils

import android.content.Context
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingPeriodicWorkPolicy
import com.example.service.SchedulingWorker
import java.util.concurrent.TimeUnit

object WorkerUtils {
    fun setupSchedulingWorker(context: Context) {
        val workRequest = PeriodicWorkRequestBuilder<SchedulingWorker>(15, TimeUnit.MINUTES)
            .build()
        
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "SchedulingWorker",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }
}
