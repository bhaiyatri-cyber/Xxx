package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun XFlowTheme(
    themeColor: Long = 0xFF00E5FF,
    content: @Composable () -> Unit,
) {
    val accentColor = Color(themeColor)
    
    val colorScheme = darkColorScheme(
        primary = accentColor,
        secondary = accentColor.copy(alpha = 0.8f),
        tertiary = accentColor,
        background = XFlowBackground,
        surface = XFlowSurface,
        surfaceVariant = XFlowSurfaceVariant,
        onPrimary = XFlowBackground,
        onSecondary = XFlowBackground,
        onTertiary = XFlowBackground,
        onBackground = XFlowTextPrimary,
        onSurface = XFlowTextPrimary,
        onSurfaceVariant = XFlowTextSecondary,
        error = XFlowError
    )

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
