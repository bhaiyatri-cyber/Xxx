package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailsScreen(id: Int, viewModel: XFlowViewModel, onBack: () -> Unit) {
    val schedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val schedule = schedules.find { it.id == id }

    if (schedule == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Task Details", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(XFlowSurface)
                    .padding(24.dp)
            ) {
                Column {
                    Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = XFlowSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailRow("Mode", if (schedule.isDurationMode) "Duration" else "Exact Time")
                    if (schedule.isDurationMode) {
                        DetailRow("Duration", "${schedule.durationMinutes} min")
                    } else {
                        DetailRow("Time", "${schedule.startTimeStr} - ${schedule.endTimeStr}")
                    }
                    DetailRow("Tracking", if (schedule.isOnlineMode) "Online (${schedule.selectedAppPackage})" else "Offline")
                    DetailRow("Elapsed", String.format("%02d:%02d:%02d", schedule.elapsedSeconds / 3600, (schedule.elapsedSeconds % 3600) / 60, schedule.elapsedSeconds % 60))
                    DetailRow("Status", if (schedule.isRunning) "Running" else "Waiting")
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = XFlowTextSecondary)
        Text(value, color = XFlowTextPrimary, fontWeight = FontWeight.Medium)
    }
}
