#!/bin/bash
cat << 'INNER_EOF' > temp.py
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re

# Find PremiumStudyPlanButton
btn_str = """fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500)
        )
    )
    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )"""

pattern = r'fun PremiumStudyPlanButton.*?\.border\(\s*width = 2\.dp,\s*brush = brush,\s*shape = RoundedCornerShape\(18\.dp\)\s*\)'
new_content = re.sub(pattern, btn_str, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(new_content)
INNER_EOF
python3 temp.py
