code = """
                    var shouldTrack = true
                    var waitingReason = ""
                    var autoComplete = false
                    
                    val targetTime = if (isDuration) {
                        schedule.durationMinutes * 60
                    } else {
                        try {
                            val startParts = schedule.startTimeStr.split(":")
                            val endParts = schedule.endTimeStr.split(":")
                            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
                            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
                            
                            val cal = java.util.Calendar.getInstance()
                            val currMins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
                            
                            val diffStart = startMins - currMins
                            if (diffStart in 0..5 && !upcomingNotifiedSchedules.contains(schedule.id)) {
                                upcomingNotifiedSchedules.add(schedule.id)
                                sendAlertNotification(
                                    "Upcoming Focus Session",
                                    "Your schedule '${schedule.subject}' starts in $diffStart minutes.",
                                    schedule.id + 1000
                                )
                            }
                            
                            if (currMins < startMins) {
                                shouldTrack = false
                                waitingReason = "Waiting for start time (${schedule.startTimeStr})"
                            } else if (currMins >= endMins) {
                                autoComplete = true
                            }
                            
                            val diff = endMins - startMins
                            if (diff > 0) diff * 60 else 60 * 60 // fallback to 1h
                        } catch (e: Exception) {
                            60 * 60 // fallback to 1h
                        }
                    }

                    if (autoComplete) {
                        db.dao().insertHistory(
                            com.example.data.HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = System.currentTimeMillis(),
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                status = "Completed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                        sendAlertNotification(
                            "Goal Reached 🎉",
                            "You've completed your focus session for '${schedule.subject}'!",
                            schedule.id + 2000
                        )
                        continue
                    }
                    
                    if (!shouldTrack) {
                        db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        titleText = "Scheduled: ${schedule.subject}"
                        contentText = waitingReason
                        continue
                    }
"""
print(code)
