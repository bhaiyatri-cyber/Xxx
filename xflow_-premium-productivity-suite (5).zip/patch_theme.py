import re
with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

pattern_dialog = r'\s*if\s*\(showPremiumDialog\)\s*\{.*?AlertDialog.*?Cancel.*?\}\s*\}'
content = re.sub(pattern_dialog, '\n    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)', content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)
