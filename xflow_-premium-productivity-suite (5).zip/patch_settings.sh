#!/bin/bash
sed -i 's/fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit)/fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit)/g' app/src/main/java/com/example/ui/SettingsScreen.kt

sed -i '/SettingsSection("Personalization") {/d' app/src/main/java/com/example/ui/SettingsScreen.kt
sed -i '/SettingsSection("App Details") {/i\
            SettingsSection("Personalization") {\
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Palette, title = "Theme & Appearance", onClick = onNavigateToThemeSettings)\
            }' app/src/main/java/com/example/ui/SettingsScreen.kt
