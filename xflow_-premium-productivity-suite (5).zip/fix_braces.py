with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# I will just write a script that identifies the functions and extracts them properly.
# Actually, the easiest way is to use ktlint to auto-format, but it doesn't fix missing braces.
# I will just grep the file and see where the braces are unbalanced.
def check_braces(text):
    count = 0
    lines = text.split('\n')
    for i, line in enumerate(lines):
        count += line.count('{') - line.count('}')
        if count < 0:
            print(f"Negative braces at line {i+1}: {line}")
            count = 0 # reset to continue
check_braces(content)
