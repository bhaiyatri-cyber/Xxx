with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re

new_effect = """LaunchedEffect(hasActiveSchedules) {
        if (activeSchedules.isNotEmpty()) {
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""

content = re.sub(r'LaunchedEffect\(hasActiveSchedules\)\s*\{.*?\}\s*\}', new_effect, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
