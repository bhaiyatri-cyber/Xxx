with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("    }\n    }\n    var showPermissionDialog", "    }\n    var showPermissionDialog")

content = content.replace("    Scaffold(\n            TopAppBar(", "    Scaffold(\n        topBar = {\n            TopAppBar(")

content = content.replace("colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)\n            )\n        ,", "colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)\n            )\n        },")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
