#!/bin/bash
sed -i '/fun saveStudyPlan(recurrenceDays: Int, items: List<StudyPlanItem>) {/,/    }/c\
    fun saveStudyPlan(recurrenceDays: Int, items: List<StudyPlanItem>) {\
        viewModelScope.launch {\
            val currentDayMillis = getCurrentDay()\
            val plan = StudyPlan(\
                recurrenceDays = recurrenceDays,\
                createdAt = System.currentTimeMillis(),\
                lastGeneratedDay = currentDayMillis\
            )\
            val planId = db.dao().insertStudyPlan(plan).toInt()\
            \
            val updatedItems = items.map { it.copy(planId = planId) }\
            db.dao().insertStudyPlanItems(updatedItems)\
            \
            for (item in updatedItems) {\
                val schedule = Schedule(\
                    subject = item.subject,\
                    description = item.description,\
                    isDurationMode = false,\
                    durationMinutes = 0,\
                    startTimeStr = item.startTimeStr,\
                    endTimeStr = item.endTimeStr,\
                    isOnlineMode = item.isOnlineMode,\
                    selectedAppPackage = item.selectedAppPackage,\
                    isActive = true,\
                    isFromStudyPlan = true,\
                    studyPlanId = planId,\
                    creationDate = System.currentTimeMillis()\
                )\
                db.dao().insertSchedule(schedule)\
            }\
            \
            checkAndRolloverStudyPlans()\
        }\
    }' app/src/main/java/com/example/ui/XFlowViewModel.kt
