#!/bin/bash
sed -i 's/androidx.compose.material.icons.Icons.Default.Palette/androidx.compose.material.icons.Icons.Default.Edit/g' app/src/main/java/com/example/ui/SettingsScreen.kt
