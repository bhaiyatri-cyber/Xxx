#!/bin/bash
sed -i '/androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {/i\
        val accent = XFlowAccent' app/src/main/java/com/example/ui/HomeScreen.kt
sed -i 's/color = XFlowAccent,/color = accent,/g' app/src/main/java/com/example/ui/HomeScreen.kt
sed -i 's/val bookColors = listOf(XFlowAccent/val bookColors = listOf(accent/g' app/src/main/java/com/example/ui/HomeScreen.kt
