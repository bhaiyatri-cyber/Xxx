#!/bin/bash
sed -i '1i import androidx.compose.ui.platform.LocalContext' app/src/main/java/com/example/ui/ThemeSettingsScreen.kt
sed -i 's/val r = (hsvColor.red \* 255).toLong()/val r = (hsvColor.red \* 255).toLong()\n                        val g = (hsvColor.green \* 255).toLong()\n                        val b = (hsvColor.blue \* 255).toLong()\n                        val colorLong = 0xFF000000L or (r shl 16) or (g shl 8) or b/g' app/src/main/java/com/example/ui/ThemeSettingsScreen.kt
