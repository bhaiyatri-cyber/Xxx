with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    new_lines.append(line)
    if 'topBar = {' in line:
        new_lines.append('            TopAppBar(\n')

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.writelines(new_lines)
