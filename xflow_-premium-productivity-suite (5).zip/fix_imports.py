with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# find package
pkg_idx = content.find('package ')
if pkg_idx != -1:
    pkg_end = content.find('\n', pkg_idx)
    pkg_line = content[pkg_idx:pkg_end+1]
    
    # remove pkg_line from content
    content = content[:pkg_idx] + content[pkg_end+1:]
    
    # insert pkg_line at start
    content = pkg_line + content

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
