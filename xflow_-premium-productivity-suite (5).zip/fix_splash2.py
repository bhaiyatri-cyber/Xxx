with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'r') as f:
    content = f.read()

if 'import kotlinx.coroutines.launch' not in content:
    content = content.replace('import kotlinx.coroutines.delay', 'import kotlinx.coroutines.delay\nimport kotlinx.coroutines.launch')

with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'w') as f:
    f.write(content)
