#!/bin/bash
sed -i 's/val XFlowAccent = Color(0xFF00E5FF)/val XFlowAccent: Color\n    @androidx.compose.runtime.Composable\n    @androidx.compose.runtime.ReadOnlyComposable\n    get() = androidx.compose.material3.MaterialTheme.colorScheme.primary/g' app/src/main/java/com/example/ui/theme/Color.kt
