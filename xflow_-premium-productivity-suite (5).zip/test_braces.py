with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

text = "".join(lines)
count = 0
in_string = False
for i, c in enumerate(text):
    if c == '"':
        in_string = not in_string
    if not in_string:
        if c == '{': count += 1
        elif c == '}':
            count -= 1
            if count < 0:
                print(f"Negative brace at index {i}, line {text[:i].count(chr(10))+1}")
                count = 0

print("Final count:", count)
