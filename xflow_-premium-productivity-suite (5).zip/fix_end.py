with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)\n@Composable", "    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)\n}\n\n@Composable")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
