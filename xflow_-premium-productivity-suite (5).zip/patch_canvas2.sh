#!/bin/bash
awk '
/fun AppBlockerIllustration\(\)/ { in_blocker = 1 }
/fun OfflineIllustration\(\)/ { in_offline = 1 }
/drawCircle\(/ {
    if (in_blocker) {
        replace_next = 1
    }
}
/color = XFlowAccent,/ {
    if (replace_next) {
        print "                color = accent,"
        replace_next = 0
        next
    }
}
/val bookColors = listOf\(XFlowAccent/ {
    if (in_offline) {
        print "            val bookColors = listOf(accent, XFlowSupport, XFlowError)"
        next
    }
}
{ print }
' app/src/main/java/com/example/ui/HomeScreen.kt > temp.kt
mv temp.kt app/src/main/java/com/example/ui/HomeScreen.kt
