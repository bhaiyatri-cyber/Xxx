sed -i 's/const val ABOUT = "about"/const val ABOUT = "about"\n    const val BACKUP = "backup"/g' app/src/main/java/com/example/ui/Navigation.kt
sed -i 's/composable(Routes.ABOUT) {/composable(Routes.BACKUP) {\n            BackupRestoreScreen(onBack = { navController.popBackStack() })\n        }\n        composable(Routes.ABOUT) {/g' app/src/main/java/com/example/ui/Navigation.kt
