package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CREATE_SCHEDULE = "create_schedule"
    const val TASK_DETAILS = "task_details/{id}"
    const val HISTORY = "history"
    const val PROGRESS = "progress"
    const val SETTINGS = "settings"
    const val IMAGE_TO_PDF = "image_to_pdf"
    const val PERMISSIONS = "permissions"
    const val STUDY_PLAN = "study_plan"
    const val ABOUT = "about"
    const val BACKUP = "backup"
    
    fun taskDetails(id: Int) = "task_details/$id"
}

@Composable
fun XFlowApp(
    viewModel: XFlowViewModel,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onNavigateToHome = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onNavigateToCreate = { navController.navigate(Routes.CREATE_SCHEDULE) },
                onNavigateToTask = { id -> navController.navigate(Routes.taskDetails(id)) },
                onNavigateToProgress = { navController.navigate(Routes.PROGRESS) },
                onNavigateToPermissions = { navController.navigate(Routes.PERMISSIONS) },
                onNavigateToStudyPlan = { navController.navigate(Routes.STUDY_PLAN) }
            )
        }
        composable(Routes.STUDY_PLAN) {
            StudyPlanScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.CREATE_SCHEDULE) {
            CreateScheduleScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.TASK_DETAILS) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
            TaskDetailsScreen(
                id = id,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToTask = { id -> navController.navigate(Routes.taskDetails(id)) }
            )
        }
        composable(Routes.PROGRESS) {
            ProgressScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPdf = { navController.navigate(Routes.IMAGE_TO_PDF) },
                onNavigateToPermissions = { navController.navigate(Routes.PERMISSIONS) },
                onNavigateToAbout = { navController.navigate(Routes.ABOUT) },
                onNavigateToBackup = { navController.navigate(Routes.BACKUP) }
            )
        }
        composable(Routes.PERMISSIONS) {
            PermissionsScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.IMAGE_TO_PDF) {
            ImageToPdfScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.BACKUP) {
            BackupRestoreScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.ABOUT) {
            AboutScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
