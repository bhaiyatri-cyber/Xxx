package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val XFlowBackground = Color(0xFF0A0A0A)
val XFlowSurface = Color(0xFF16191E)
val XFlowSurfaceVariant = Color(0xFF22262E)
val XFlowAccent = Color(0xFF00E5FF)
val XFlowSupport = Color(0xFF00BFA5)
val XFlowTextPrimary = Color(0xFFFFFFFF)
val XFlowTextSecondary = Color(0xFFA0AAB2)
val XFlowError = Color(0xFFFF5252)

