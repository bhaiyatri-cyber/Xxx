package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfGenerator {
    
    fun getPdfsDirectory(context: Context): File {
        val pdfDir = File(context.filesDir, "pdfs")
        if (!pdfDir.exists()) pdfDir.mkdirs()
        return pdfDir
    }

    suspend fun createPdfFromImages(context: Context, imageUris: List<Uri>): File? = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) return@withContext null
        val pdfDocument = PdfDocument()
        
        try {
            for ((index, uri) in imageUris.withIndex()) {
                val bitmap = getBitmap(context, uri) ?: continue
                
                val pageWidth = 595
                val pageHeight = 842
                
                val scale = Math.min(pageWidth.toFloat() / bitmap.width, pageHeight.toFloat() / bitmap.height)
                val scaledWidth = (bitmap.width * scale).toInt()
                val scaledHeight = (bitmap.height * scale).toInt()
                
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
                
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                
                val canvas = page.canvas
                val left = (pageWidth - scaledWidth) / 2f
                val top = (pageHeight - scaledHeight) / 2f
                
                canvas.drawBitmap(scaledBitmap, left, top, null)
                pdfDocument.finishPage(page)
                
                if (scaledBitmap != bitmap) {
                    scaledBitmap.recycle()
                }
                bitmap.recycle()
            }
            
            val pdfDir = getPdfsDirectory(context)
            val pdfFile = File(pdfDir, "XFlow_Converted_${System.currentTimeMillis()}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            return@withContext pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext null
        } finally {
            pdfDocument.close()
        }
    }

    private fun getBitmap(context: Context, uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, _, _ ->
                    decoder.isMutableRequired = true
                }
            } else {
                MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    fun getSavedPdfs(context: Context): List<File> {
        val pdfDir = getPdfsDirectory(context)
        return pdfDir.listFiles()?.filter { it.extension == "pdf" }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    
    fun renamePdf(file: File, newName: String): File? {
        var safeName = newName
        if (!safeName.lowercase().endsWith(".pdf")) {
            safeName += ".pdf"
        }
        val newFile = File(file.parentFile, safeName)
        if (file.renameTo(newFile)) {
            return newFile
        }
        return null
    }

    suspend fun savePdfToDownloads(context: Context, file: File): Boolean = withContext(Dispatchers.IO) {
        try {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Files.getContentUri("external"), contentValues)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input ->
                        input.copyTo(out)
                    }
                }
                return@withContext true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext false
    }
}
