sed -i 's/version = 3/version = 4/g' app/src/main/java/com/example/data/Database.kt
