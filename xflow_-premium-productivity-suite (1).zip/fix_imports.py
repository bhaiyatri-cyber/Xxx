with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

imports = [
    "import androidx.compose.animation.core.animateFloatAsState",
    "import androidx.compose.animation.core.Animatable",
    "import androidx.compose.animation.core.tween",
    "import androidx.compose.animation.AnimatedVisibility",
    "import androidx.compose.animation.fadeIn",
    "import androidx.compose.animation.scaleIn",
]

for imp in imports:
    if imp not in content:
        content = content.replace("import androidx.compose.runtime.*", f"import androidx.compose.runtime.*\n{imp}")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
