import re

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

new_vars = """    private val _themeStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("theme_style", "Dark") ?: "Dark")
    val themeStyle: StateFlow<String> = _themeStyle

    private val _cardStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("card_style", "Solid") ?: "Solid")
    val cardStyle: StateFlow<String> = _cardStyle

    fun updateThemeStyle(style: String) {
        prefs.edit().putString("theme_style", style).apply()
        _themeStyle.value = style
    }

    fun updateCardStyle(style: String) {
        prefs.edit().putString("card_style", style).apply()
        _cardStyle.value = style
    }
"""

content = content.replace("""    private val _themeStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("theme_style", "Dark") ?: "Dark")
    val themeStyle: StateFlow<String> = _themeStyle

    fun updateThemeStyle(style: String) {
        prefs.edit().putString("theme_style", style).apply()
        _themeStyle.value = style
    }""", new_vars)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
