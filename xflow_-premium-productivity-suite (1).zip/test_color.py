import re
with open('app/src/main/java/com/example/ui/theme/Color.kt', 'r') as f:
    content = f.read()
print(content)
