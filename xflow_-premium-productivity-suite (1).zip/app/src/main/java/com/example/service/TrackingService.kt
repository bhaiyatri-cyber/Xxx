package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.data.Schedule
import com.example.data.XFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class TrackingService : Service() {
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    private lateinit var db: XFlowDatabase
    
    private val CHANNEL_ID = "TrackingChannel"
    private val ALERT_CHANNEL_ID = "AlertChannel"
    private val NOTIFICATION_ID = 1
    
    private val upcomingNotifiedSchedules = mutableSetOf<Int>()
    
    private var isTrackingLoopRunning = false

    override fun onCreate() {
        super.onCreate()
        db = XFlowDatabase.getDatabase(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val scheduleId = intent?.getIntExtra("schedule_id", -1) ?: -1
        
        val notification = createNotification("Initializing...", "Starting tracker")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (scheduleId != -1) {
            // Wait, we just track all active schedules that are supposed to be tracked
            // The service can just query active schedules periodically
            if (!isTrackingLoopRunning) {
                isTrackingLoopRunning = true
                startTrackingLoop()
            }
        }
        
        return START_STICKY
    }
    
    private fun startTrackingLoop() {
        serviceScope.launch {
            val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            while (true) {
                val activeSchedules = db.dao().getActiveSchedulesSync()
                if (activeSchedules.isEmpty()) {
                    // Stop service if no active schedules
                    stopSelf()
                    break
                }
                
                val currentApp = getForegroundApp()
                val isScreenOn = powerManager.isInteractive
                
                var trackingAny = false
                var titleText = "Waiting for condition..."
                var contentText = "Ensure correct app is open or screen is locked."
                
                for (schedule in activeSchedules) {
                    var shouldTrack = true
                    var waitingReason = ""
                    var autoComplete = false

                    val isDuration = schedule.isDurationMode
                    val targetTime = if (isDuration) {
                        schedule.durationMinutes * 60
                    } else {
                        try {
                            val startParts = schedule.startTimeStr.split(":")
                            val endParts = schedule.endTimeStr.split(":")
                            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
                            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
                            
                            val cal = java.util.Calendar.getInstance()
                            val currMins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
                            
                            val diffStart = startMins - currMins
                            if (diffStart in 0..5 && !upcomingNotifiedSchedules.contains(schedule.id)) {
                                upcomingNotifiedSchedules.add(schedule.id)
                                sendAlertNotification(
                                    "Upcoming Focus Session",
                                    "Your schedule '${schedule.subject}' starts in $diffStart minutes.",
                                    schedule.id + 1000
                                )
                            }
                            
                            if (currMins < startMins) {
                                shouldTrack = false
                                waitingReason = "Waiting for start time (${schedule.startTimeStr})"
                            } else if (currMins >= endMins) {
                                autoComplete = true
                            }
                            
                            val diff = endMins - startMins
                            if (diff > 0) diff * 60 else 60 * 60 // fallback to 1h
                        } catch (e: Exception) {
                            60 * 60 // fallback to 1h
                        }
                    }

                    if (autoComplete) {
                        db.dao().insertHistory(
                            com.example.data.HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = System.currentTimeMillis(),
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                status = "Completed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                        sendAlertNotification(
                            "Goal Reached \uD83C\uDF89",
                            "You've completed your focus session for '${schedule.subject}'!",
                            schedule.id + 2000
                        )
                        continue
                    }
                    
                    if (!shouldTrack) {
                        db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        titleText = "Scheduled: ${schedule.subject}"
                        contentText = waitingReason
                        continue
                    }

                    if (schedule.isOnlineMode && schedule.selectedAppPackage != null) {
                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            // increment elapsed
                            val newElapsed = schedule.elapsedSeconds + 1
                            db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                            
                            titleText = "Tracking: ${schedule.subject}"
                            contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            
                            if (newElapsed >= targetTime) {
                                // complete
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = newElapsed,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            }
                        } else {
                            db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        }
                    } else if (!schedule.isOnlineMode) {
                        // Offline Mode: Only track when screen is OFF (locked)
                        if (!isScreenOn) {
                            trackingAny = true
                            val newElapsed = schedule.elapsedSeconds + 1
                            db.dao().updateScheduleProgress(schedule.id, newElapsed, true)

                            titleText = "Offline Tracking: ${schedule.subject}"
                            contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"

                            if (newElapsed >= targetTime) {
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = newElapsed,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            }
                        } else {
                            db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            titleText = "Paused: ${schedule.subject}"
                            contentText = "Screen is ON. Lock phone to resume offline tracking."
                        }
                    }
                }
                
                updateNotification(titleText, contentText)
                
                delay(1000)
            }
        }
    }

    private fun getForegroundApp(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 1000 * 60 * 5 // last 5 minutes
        
        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        var event = UsageEvents.Event()
        var foregroundPackage: String? = null
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                foregroundPackage = event.packageName
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
                if (foregroundPackage == event.packageName) {
                    foregroundPackage = null
                }
            }
        }
        return foregroundPackage
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Tracking Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
            
            val alertChannel = NotificationChannel(
                ALERT_CHANNEL_ID,
                "Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(alertChannel)
        }
    }

    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
                
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Permission not granted, ignore
        }
    }

    private fun createNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }
    
    private fun updateNotification(title: String, text: String) {
        val notification = createNotification(title, text)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
