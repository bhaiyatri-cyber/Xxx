package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class XFlowColors(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val support: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val error: Color
)

val LocalXFlowColors = staticCompositionLocalOf { darkColors() }

fun darkColors() = XFlowColors(
    background = Color(0xFF0A0A0A),
    surface = Color(0xFF16191E),
    surfaceVariant = Color(0xFF22262E),
    support = Color(0xFF00BFA5),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA0AAB2),
    error = Color(0xFFFF5252)
)

fun lightColors() = XFlowColors(
    background = Color(0xFFF5F5F5),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE0E0E0),
    support = Color(0xFF00BFA5),
    textPrimary = Color(0xFF000000),
    textSecondary = Color(0xFF555555),
    error = Color(0xFFD32F2F)
)

fun neonColors() = XFlowColors(
    background = Color(0xFF000000),
    surface = Color(0xFF050014),
    surfaceVariant = Color(0xFF120030),
    support = Color(0xFF00E5FF),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFA090D0),
    error = Color(0xFFFF0055)
)

val XFlowBackground: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.background

val XFlowSurface: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.surface

val XFlowSurfaceVariant: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.surfaceVariant

val XFlowSupport: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.support

val XFlowTextPrimary: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.textPrimary

val XFlowTextSecondary: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.textSecondary

val XFlowError: Color
    @Composable
    @ReadOnlyComposable
    get() = LocalXFlowColors.current.error

val XFlowAccent: Color
    @Composable
    @ReadOnlyComposable
    get() = androidx.compose.material3.MaterialTheme.colorScheme.primary
