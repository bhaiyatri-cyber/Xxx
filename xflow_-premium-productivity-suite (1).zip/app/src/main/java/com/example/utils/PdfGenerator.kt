package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object PdfGenerator {
    suspend fun createPdfFromImages(context: Context, imageUris: List<Uri>): File? = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) return@withContext null

        val pdfDocument = PdfDocument()
        
        try {
            for ((index, uri) in imageUris.withIndex()) {
                val bitmap = getBitmap(context, uri) ?: continue
                
                // A4 size roughly in points (72 points per inch -> 595 x 842)
                val pageWidth = 595
                val pageHeight = 842
                
                // Scale bitmap to fit page
                val scale = Math.min(pageWidth.toFloat() / bitmap.width, pageHeight.toFloat() / bitmap.height)
                val scaledWidth = (bitmap.width * scale).toInt()
                val scaledHeight = (bitmap.height * scale).toInt()
                
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
                
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                
                val canvas = page.canvas
                val left = (pageWidth - scaledWidth) / 2f
                val top = (pageHeight - scaledHeight) / 2f
                
                canvas.drawBitmap(scaledBitmap, left, top, null)
                pdfDocument.finishPage(page)
                
                if (scaledBitmap != bitmap) {
                    scaledBitmap.recycle()
                }
                bitmap.recycle()
            }
            
            val pdfDir = File(context.cacheDir, "pdfs")
            if (!pdfDir.exists()) pdfDir.mkdirs()
            
            val pdfFile = File(pdfDir, "XFlow_Converted_${System.currentTimeMillis()}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            return@withContext pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext null
        } finally {
            pdfDocument.close()
        }
    }

    private fun getBitmap(context: Context, uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
            } else {
                MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
