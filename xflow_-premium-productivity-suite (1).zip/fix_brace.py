with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("            }\n        }\n    }\n}\n\n@Composable\nfun OnlineAnimation()", "            }\n        }\n    }\n    }\n}\n\n@Composable\nfun OnlineAnimation()")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
