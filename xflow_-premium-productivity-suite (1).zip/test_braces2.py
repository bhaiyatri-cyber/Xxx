with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()
open_braces = 0
for i, char in enumerate(content):
    if char == '{':
        open_braces += 1
    elif char == '}':
        open_braces -= 1
print(f"Open braces remaining: {open_braces}")
