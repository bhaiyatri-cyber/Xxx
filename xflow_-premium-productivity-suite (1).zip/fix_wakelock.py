with open('app/src/main/java/com/example/service/TrackingService.kt', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add wakeLock variable
if 'wakeLock: android.os.PowerManager.WakeLock?' not in content:
    content = content.replace(
        'private var isTrackingLoopRunning = false',
        'private var isTrackingLoopRunning = false\n    private var wakeLock: android.os.PowerManager.WakeLock? = null'
    )

# 2. Acquire wakeLock in onCreate
if 'wakeLock = powerManager.newWakeLock' not in content:
    content = content.replace(
        'createNotificationChannel()\n    }',
        'createNotificationChannel()\n        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager\n        wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "XFlow::TrackingWakeLock")\n        wakeLock?.acquire()\n    }'
    )

# 3. Release wakeLock in onDestroy
if 'wakeLock?.release()' not in content:
    content = content.replace(
        'serviceJob.cancel()\n    }',
        'serviceJob.cancel()\n        if (wakeLock?.isHeld == true) {\n            wakeLock?.release()\n        }\n    }'
    )

# 4. Modify getForegroundApp to look back further (1 hour instead of 1 minute)
if 'last 5 minutes' in content or '1000 * 60 * 1' in content:
    content = content.replace(
        'val startTime = endTime - 1000 * 60 * 1 // last 5 minutes',
        'val startTime = endTime - 1000 * 60 * 60 * 24L // look back 24h to be safe'
    )

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w', encoding='utf-8') as f:
    f.write(content)
