import re

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

new_theme_vars = """    private val _themeColor = kotlinx.coroutines.flow.MutableStateFlow(prefs.getLong("theme_color", 0xFF00E5FF))
    val themeColor: StateFlow<Long> = _themeColor

    private val _themeStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("theme_style", "Dark") ?: "Dark")
    val themeStyle: StateFlow<String> = _themeStyle

    fun updateThemeStyle(style: String) {
        prefs.edit().putString("theme_style", style).apply()
        _themeStyle.value = style
    }
"""

content = content.replace('    private val _themeColor = kotlinx.coroutines.flow.MutableStateFlow(prefs.getLong("theme_color", 0xFF00E5FF))\n    val themeColor: StateFlow<Long> = _themeColor', new_theme_vars)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
