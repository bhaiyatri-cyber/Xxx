with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    lines = f.readlines()
for i, line in enumerate(lines):
    if 'enum class StudyStatus' in line or 'PremiumStudyPlanButton' in line or 'OnlineAnimation' in line:
        print(f"{i+1}: {line.strip()}")
