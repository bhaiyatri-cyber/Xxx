import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Collect card style in HomeScreen
content = content.replace(
    'val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()',
    'val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()\n    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()'
)

# Pass cardStyle to ScheduleCard
content = content.replace(
    'ScheduleCard(schedule, onClick = { onNavigateToTask(schedule.id) })',
    'ScheduleCard(schedule, cardStyle = cardStyle, onClick = { onNavigateToTask(schedule.id) })'
)

# Update ScheduleCard signature
content = content.replace(
    'fun ScheduleCard(schedule: Schedule, onClick: () -> Unit)',
    'fun ScheduleCard(schedule: Schedule, cardStyle: String = "Solid", onClick: () -> Unit)'
)

# Apply image background to ScheduleCard
new_modifier = """    val isImageStyle = cardStyle == "Image" && schedule.isFromStudyPlan

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) Color.Transparent else containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPremium) 4.dp else 2.dp),
        border = androidx.compose.foundation.BorderStroke(if (isPremium) 2.dp else 1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Box(modifier = Modifier.padding(16.dp)) {"""

content = re.sub(
r"""    Card\(
        modifier = Modifier
            .fillMaxWidth\(\)
            .clickable\(onClick = onClick\)
            .graphicsLayer \{
                scaleX = scale.value
                scaleY = scale.value
            \},
        shape = RoundedCornerShape\(16.dp\),
        colors = CardDefaults.cardColors\(containerColor = containerColor\),
        elevation = CardDefaults.cardElevation\(defaultElevation = if \(isPremium\) 4.dp else 2.dp\),
        border = androidx.compose.foundation.BorderStroke\(if \(isPremium\) 2.dp else 1.dp, borderColor\)
    \) \{
        Box\(modifier = Modifier.padding\(16.dp\)\) \{""",
new_modifier,
content
)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
