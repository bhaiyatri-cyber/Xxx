import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

# Add cardStyle collection in HistoryScreen
content = content.replace(
    'val history by viewModel.history.collectAsStateWithLifecycle()',
    'val history by viewModel.history.collectAsStateWithLifecycle()\n    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()'
)

# Pass cardStyle to HistoryCard
content = content.replace(
    'HistoryCard(session)',
    'HistoryCard(session, cardStyle = cardStyle)'
)

# Update HistoryCard signature
content = content.replace(
    'fun HistoryCard(session: HistorySession)',
    'fun HistoryCard(session: HistorySession, cardStyle: String = "Solid")'
)

# Apply image background to HistoryCard
new_modifier = """    val isImageStyle = cardStyle == "Image"
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) androidx.compose.ui.graphics.Color.Transparent else XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    androidx.compose.ui.graphics.Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {"""

content = re.sub(
r"""    Card\(
        modifier = Modifier
            .fillMaxWidth\(\)
            .clickable \{ showSheet = true \},
        shape = RoundedCornerShape\(16.dp\),
        colors = CardDefaults.cardColors\(containerColor = XFlowSurface\),
        elevation = CardDefaults.cardElevation\(defaultElevation = 2.dp\),
        border = androidx.compose.foundation.BorderStroke\(1.dp, XFlowSurfaceVariant\)
    \) \{
        Column\(modifier = Modifier.padding\(16.dp\)\) \{""",
new_modifier,
content
)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
