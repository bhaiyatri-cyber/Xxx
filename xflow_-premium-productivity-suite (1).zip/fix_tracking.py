import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Add wake lock variable
if 'private var wakeLock: android.os.PowerManager.WakeLock? = null' not in content:
    content = content.replace(
        'private var isTrackingLoopRunning = false',
        'private var isTrackingLoopRunning = false\n    private var wakeLock: android.os.PowerManager.WakeLock? = null'
    )

# Acquire wake lock in onCreate or onStartCommand
if 'wakeLock = powerManager.newWakeLock' not in content:
    content = content.replace(
        'db = XFlowDatabase.getDatabase(this)\n        createNotificationChannel()',
        'db = XFlowDatabase.getDatabase(this)\n        createNotificationChannel()\n        \n        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager\n        wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "XFlow::TrackingWakeLock")\n        wakeLock?.acquire()'
    )

# Release wake lock in onDestroy
if 'wakeLock?.release()' not in content:
    content = content.replace(
        'super.onDestroy()\n        serviceJob.cancel()',
        'super.onDestroy()\n        serviceJob.cancel()\n        if (wakeLock?.isHeld == true) {\n            wakeLock?.release()\n        }'
    )

# Fix getForegroundApp to look back 24 hours just in case
content = content.replace(
    'val startTime = endTime - 1000 * 60 * 1 // last 5 minutes',
    'val startTime = endTime - 1000 * 60 * 60 * 24L // last 24 hours to catch old resumes'
)
content = content.replace(
    'val startTime = endTime - 1000 * 60 * 1',
    'val startTime = endTime - 1000 * 60 * 60 * 24L'
)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
