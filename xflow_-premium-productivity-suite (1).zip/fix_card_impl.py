import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

new_card = """@Composable
fun ScheduleCard(schedule: Schedule, onClick: () -> Unit) {
    val targetTime = if (schedule.isDurationMode) {
        schedule.durationMinutes * 60
    } else {
        try {
            val startParts = schedule.startTimeStr.split(":")
            val endParts = schedule.endTimeStr.split(":")
            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
            val diff = if (endMins >= startMins) endMins - startMins else (24 * 60 - startMins) + endMins
            diff * 60
        } catch(e:Exception) { 3600 }
    }

    val progress = if (targetTime > 0) (schedule.elapsedSeconds.toFloat() / targetTime).coerceIn(0f, 1f) else 0f
    
    val status = when {
        schedule.elapsedSeconds >= targetTime -> StudyStatus.COMPLETED
        schedule.isRunning -> StudyStatus.RUNNING
        schedule.elapsedSeconds > 0 -> StudyStatus.PAUSED
        else -> StudyStatus.UPCOMING
    }

    val elapsedTimeStr = String.format("%02d:%02d", schedule.elapsedSeconds / 60, schedule.elapsedSeconds % 60)
    val totalTimeStr = String.format("%02d:%02d", targetTime / 60, targetTime % 60)

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(400),
        label = "progress"
    )

    val scale = remember { Animatable(1f) }

    LaunchedEffect(status) {
        if (status == StudyStatus.COMPLETED) {
            scale.animateTo(1.02f, animationSpec = tween(150))
            scale.animateTo(1f, animationSpec = tween(150))
        }
    }

    val isPremium = schedule.isFromStudyPlan
    val borderColor = if (isPremium) androidx.compose.ui.graphics.Color(0xFFFFD700) else XFlowSurfaceVariant
    val containerColor = if (isPremium) XFlowSurface.copy(alpha = 0.9f) else XFlowSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPremium) 4.dp else 2.dp),
        border = androidx.compose.foundation.BorderStroke(if (isPremium) 2.dp else 1.dp, borderColor)
    ) {
        Box(modifier = Modifier.padding(16.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            if (isPremium) {
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Default.WorkspacePremium, contentDescription = "Premium", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Badge(text = if (schedule.isOnlineMode) "Online" else "Offline", isAccent = true)
                            
                            when (status) {
                                StudyStatus.UPCOMING -> Badge(text = "Upcoming")
                                StudyStatus.RUNNING -> Badge(text = "In Progress", isAccent = true)
                                StudyStatus.PAUSED -> Badge(text = "Paused")
                                StudyStatus.COMPLETED -> Badge(text = "Completed", isAccent = true)
                                else -> {}
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    if (schedule.isOnlineMode) {
                        OnlineAnimation()
                    } else {
                        OfflineIllustration()
                    }
                }

                Spacer(Modifier.height(16.dp))

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = XFlowAccent,
                    trackColor = XFlowSurfaceVariant
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val percentage = (animatedProgress * 100).toInt()
                    Text(
                        text = "$percentage%",
                        color = XFlowAccent,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    if (status == StudyStatus.RUNNING || status == StudyStatus.PAUSED) {
                        Text(
                            text = "⏱ $elapsedTimeStr / $totalTimeStr",
                            color = XFlowTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else if (status == StudyStatus.COMPLETED) {
                        Text(
                            text = getResultStatus(percentage),
                            color = XFlowTextPrimary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = "⏱ $totalTimeStr",
                            color = XFlowTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                
                AnimatedVisibility(
                    visible = status == StudyStatus.COMPLETED,
                    enter = fadeIn(tween(300)) + scaleIn(tween(350))
                ) {
                    Column(modifier = Modifier.padding(top = 12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✓ Session Completed", color = XFlowSupport, fontWeight = FontWeight.Bold)
                        Text(getResultStatus((progress * 100).toInt()), color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
"""

# Now we need to find the old ScheduleCard and replace it.
start_idx = content.find("fun ScheduleCard(")
if start_idx != -1:
    end_idx = content.find("@Composable\nfun OnlineAnimation()", start_idx)
    if end_idx != -1:
        # Before replacing, make sure we got the whole function
        content = content[:start_idx] + new_card + content[end_idx:]
    else:
        print("Couldn't find OnlineAnimation")
else:
    print("Couldn't find ScheduleCard")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
